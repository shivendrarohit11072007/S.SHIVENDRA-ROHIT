# PocketSmart AI: Your Smart Budget & Recommendation Assistant

## 1. Abstract
PocketSmart AI is a web-based personal budgeting assistant that helps users record expenses, monitor spending, understand category-wise expenditure, and receive automated budgeting recommendations. The system provides a simple dashboard and stores expense records locally. A lightweight recommendation engine analyzes spending patterns and produces practical observations without requiring an external AI API.

## 2. Introduction
Managing personal finances requires awareness of income, expenses, spending categories, and remaining funds. Manual tracking can be inconvenient and users may find it difficult to identify spending patterns. PocketSmart AI provides a centralized interface for entering transactions and viewing a summarized financial picture.

## 3. Problem Statement
Users often record expenses inconsistently and may not know which categories consume the largest share of their budget. A simple system is needed to organize transactions, calculate totals, analyze categories, and provide understandable recommendations.

## 4. Objectives
1. Develop a web-based personal budget assistant.
2. Record and manage expense transactions.
3. Calculate total spending and remaining income.
4. Categorize expenses.
5. Analyze category-wise spending.
6. Generate automated budget recommendations.
7. Export expense records as CSV.
8. Provide a foundation for future generative-AI integration.

## 5. Scope
The current system covers expense recording, dashboard summaries, category analysis, recommendations, deletion, and CSV export. Future versions can add authentication, databases, bank integration, receipt OCR, forecasting, natural-language chat, and advanced AI recommendations.

## 6. System Requirements
### Hardware
- Dual-core processor or better
- 4 GB RAM
- 200 MB free storage
- Modern display

### Software
- Windows, Linux, or macOS
- Python 3.10+
- Flask
- Modern browser such as Chrome, Edge, or Firefox

## 7. Technologies Used
### Python
Used for backend logic and data processing.

### Flask
Used for routing, API endpoints, and serving the web interface.

### HTML/CSS
Used to build the dashboard and responsive visual design.

### JavaScript
Used for dynamic form submission, dashboard refresh, transaction deletion, and chart rendering.

### JSON
Used as lightweight local storage for the demo version.

## 8. System Architecture
```text
+---------------------+
|       USER          |
+----------+----------+
           |
           v
+---------------------+
| Web Dashboard       |
| HTML/CSS/JavaScript |
+----------+----------+
           |
           v
+---------------------+
| Flask Backend       |
| REST-style APIs     |
+----------+----------+
           |
           v
+---------------------+
| Expense Analyzer    |
| Totals + Categories |
+----------+----------+
           |
           v
+---------------------+
| Recommendation      |
| Engine              |
+----------+----------+
           |
           v
+---------------------+
| JSON Storage / CSV  |
+---------------------+
```

## 9. Main Modules
### 9.1 Dashboard Module
Displays income, total spending, remaining amount, and savings rate.

### 9.2 Expense Management Module
Allows users to add and delete expense records.

### 9.3 Category Analysis Module
Groups expenses by categories such as Food, Transport, Shopping, Bills, Entertainment, Health, Education, and Other.

### 9.4 Recommendation Module
Analyzes the income-to-spending relationship and category patterns to provide general budgeting observations.

### 9.5 Export Module
Exports all recorded transactions to CSV.

## 10. Working
1. User opens PocketSmart AI.
2. User enters monthly income.
3. User adds expense details.
4. The browser sends the data to Flask.
5. Flask validates and stores the transaction.
6. The summary API calculates totals and category values.
7. The recommendation engine generates observations.
8. The dashboard displays updated results.
9. User can delete transactions or export them as CSV.

## 11. Recommendation Logic
The demo recommendation engine uses transparent rules:
- If recorded spending exceeds 80% of income, it suggests reviewing non-essential spending.
- If spending exceeds 60%, it suggests setting category limits.
- If spending is below 60%, it suggests considering savings allocation.
- It identifies the highest-spend category.
- It provides additional observations for high Food or Shopping shares.

These rules are intentionally simple and explainable. A future LLM integration can provide richer natural-language recommendations.

## 12. Data Model
Each expense contains:
- id
- date
- category
- description
- amount

Example:
```json
{
  "id": 123456,
  "date": "2026-09-28",
  "category": "Food",
  "description": "Lunch",
  "amount": 150
}
```

## 13. Project Structure
```text
PocketSmart_AI/
├── app.py
├── requirements.txt
├── README.md
├── PROJECT_DOCUMENTATION.md
├── data/
│   └── expenses.json
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## 14. Algorithm
Input: Monthly income and expense transactions.

1. Read income.
2. Read expense records.
3. Validate expense fields.
4. Calculate total expense.
5. Calculate remaining amount.
6. Group expenses by category.
7. Calculate savings rate.
8. Identify the highest spending category.
9. Apply recommendation rules.
10. Display the results.

## 15. Testing
### Test 1 — Add valid expense
Expected: Transaction is saved and dashboard updates.

### Test 2 — Invalid amount
Expected: Validation error is displayed.

### Test 3 — Delete transaction
Expected: Transaction is removed and totals update.

### Test 4 — Category analysis
Expected: Category totals reflect recorded transactions.

### Test 5 — CSV export
Expected: Browser downloads a CSV containing transaction records.

### Test 6 — Empty dashboard
Expected: Zero totals and a prompt to add expenses are shown.

## 16. Advantages
- Simple and user-friendly
- Fast expense tracking
- Clear spending analysis
- Explainable recommendations
- No external API key required
- Lightweight local storage
- CSV export
- Easy to extend

## 17. Limitations
- The demo stores data locally in JSON.
- No user authentication is included.
- No bank-account synchronization is included.
- Recommendations are general and rule-based.
- It does not provide professional financial advice.
- No automatic receipt scanning is included.

## 18. Future Enhancements
- Generative AI assistant
- Login and user profiles
- SQLite/PostgreSQL database
- Receipt image OCR
- Bank/UPI transaction import where supported
- Spending forecasts
- Budget alerts
- Recurring expense detection
- PDF reports
- Mobile application
- Multi-language support
- Secure cloud synchronization

## 19. Security
A production version should use authentication, authorization, encrypted connections, secure secrets, input validation, database access controls, backups, and appropriate privacy practices.

## 20. Conclusion
PocketSmart AI provides a practical demonstration of how web development and automated analysis can support personal budgeting. The system tracks expenses, summarizes spending, identifies category patterns, and provides understandable recommendations. Its modular design makes it suitable for further development into an AI-powered personal finance assistant.

## 21. References
1. Python Documentation
2. Flask Documentation
3. HTML5 Documentation
4. CSS Documentation
5. JavaScript Documentation
