# PocketSmart AI — Smart Budget & Recommendation Assistant

PocketSmart AI is a ready-to-run Flask web application for tracking expenses, analyzing spending, and generating simple personalized budget recommendations.

## Features
- Monthly income input
- Add expenses with date, category, description and amount
- Dashboard with income, spending, remaining balance and savings rate
- Category-wise spending analysis
- Smart rule-based recommendations
- Expense deletion
- CSV export
- Local JSON data storage
- Responsive modern interface
- No API key or database server required

## Tech Stack
- Python
- Flask
- HTML5
- CSS3
- JavaScript
- JSON local storage

## Run on Windows
```text
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open: http://127.0.0.1:5000

## Run on macOS/Linux
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Data
Expenses are stored locally in `data/expenses.json`.

## AI Upgrade
The included recommendation engine is deterministic so the project works without external API keys. For a true generative-AI version, replace or extend the `recommendations()` function with a secure LLM integration and keep API keys in environment variables.

## Disclaimer
PocketSmart AI is an educational budgeting project. Recommendations are general informational suggestions and are not financial advice.
