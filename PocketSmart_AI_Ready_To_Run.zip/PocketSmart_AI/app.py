from flask import Flask, render_template, request, jsonify, send_file
from datetime import datetime
from io import BytesIO
import json, os, csv

app = Flask(__name__)
DATA_FILE = os.path.join("data", "expenses.json")

CATEGORIES = ["Food", "Transport", "Shopping", "Bills", "Entertainment", "Health", "Education", "Other"]

def load_expenses():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []

def save_expenses(items):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)

def recommendations(income, expenses):
    total = sum(float(x["amount"]) for x in expenses)
    by_cat = {}
    for x in expenses:
        by_cat[x["category"]] = by_cat.get(x["category"], 0) + float(x["amount"])
    recs = []
    if income > 0:
        rate = total / income * 100
        if rate > 80:
            recs.append("Your recorded spending is above 80% of income. Review non-essential expenses and set category limits.")
        elif rate > 60:
            recs.append("More than 60% of income is recorded as spending. Consider setting weekly limits for flexible categories.")
        else:
            recs.append("Your recorded spending is below 60% of income. Consider allocating part of the remaining amount to savings.")
    if by_cat:
        top = max(by_cat, key=by_cat.get)
        recs.append(f"{top} is your highest-spend category at {by_cat[top]:,.2f}. Review recent transactions in this category.")
    if "Food" in by_cat and by_cat["Food"] > total * 0.25:
        recs.append("Food represents more than 25% of recorded spending. Planning meals and comparing options may reduce discretionary costs.")
    if "Shopping" in by_cat and by_cat["Shopping"] > total * 0.20:
        recs.append("Shopping represents more than 20% of recorded spending. Consider a planned-purchase list and a monthly shopping cap.")
    if not recs:
        recs.append("Add a few expenses to receive personalized budget observations.")
    return recs

@app.route("/")
def index():
    return render_template("index.html", categories=CATEGORIES)

@app.route("/api/expenses", methods=["GET", "POST", "DELETE"])
def expenses_api():
    items = load_expenses()
    if request.method == "GET":
        return jsonify(items)
    if request.method == "POST":
        data = request.get_json(force=True)
        try:
            amount = float(data.get("amount", 0))
        except ValueError:
            amount = 0
        if amount <= 0 or not data.get("category") or not data.get("description"):
            return jsonify({"error": "Please provide a valid amount, category and description."}), 400
        item = {
            "id": int(datetime.now().timestamp() * 1000),
            "date": data.get("date") or datetime.now().strftime("%Y-%m-%d"),
            "category": data["category"],
            "description": data["description"].strip(),
            "amount": round(amount, 2)
        }
        items.append(item)
        save_expenses(items)
        return jsonify(item), 201
    item_id = request.args.get("id")
    items = [x for x in items if str(x["id"]) != str(item_id)]
    save_expenses(items)
    return jsonify({"success": True})

@app.route("/api/summary")
def summary():
    try:
        income = float(request.args.get("income", 0))
    except ValueError:
        income = 0
    items = load_expenses()
    total = round(sum(float(x["amount"]) for x in items), 2)
    by_cat = {c: 0 for c in CATEGORIES}
    for x in items:
        by_cat[x["category"]] = round(by_cat.get(x["category"], 0) + float(x["amount"]), 2)
    remaining = round(income - total, 2)
    return jsonify({
        "income": income,
        "total": total,
        "remaining": remaining,
        "savings_rate": round((remaining / income * 100), 1) if income else 0,
        "by_category": by_cat,
        "recommendations": recommendations(income, items)
    })

@app.route("/download/csv")
def download_csv():
    items = load_expenses()
    out = BytesIO()
    text = []
    text.append("Date,Category,Description,Amount")
    for x in items:
        desc = '"' + str(x["description"]).replace('"', '""') + '"'
        text.append(f'{x["date"]},{x["category"]},{desc},{x["amount"]}')
    out.write(("\n".join(text)).encode("utf-8"))
    out.seek(0)
    return send_file(out, as_attachment=True, download_name="PocketSmart_expenses.csv", mimetype="text/csv")

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
